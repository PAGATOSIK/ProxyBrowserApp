# ProxyBrowserApp

Android WebView browser with address/search bar and HTTP proxy settings.

## Build in GitHub Actions
1. Upload the **contents** of this folder to the root of your GitHub repository (keep the folder paths).
2. Commit the files to the `main` branch.
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and wait for the run to finish.
5. Open the successful run and download the `ProxyBrowserApp-debug` artifact.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`.

You can also start a build manually from Actions → Build Android APK → Run workflow.

## Proxy notes
The proxy setting uses AndroidX WebKit's `ProxyController` and applies to this app's WebView, not all phone traffic. It requires a recent Android System WebView that supports `PROXY_OVERRIDE`. This is an HTTP proxy host and port setting; it does not implement SOCKS, proxy authentication, per-domain routing, or VPN-wide routing. Availability and behavior depend on the device's WebView implementation.

This is a debug APK for testing, not a Play Store release.
