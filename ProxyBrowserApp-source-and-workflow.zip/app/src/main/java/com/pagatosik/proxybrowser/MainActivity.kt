package com.pagatosik.proxybrowser

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebChromeClient
import androidx.webkit.ProxyConfig
import androidx.webkit.ProxyController
import androidx.webkit.WebViewFeature
import java.net.URLEncoder
import java.util.concurrent.Executor

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var status: TextView
    private var proxyHost = ""
    private var proxyPort = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        address = EditText(this).apply {
            hint = "Введите адрес или поисковый запрос"
            singleLine = true
            imeOptions = EditorInfo.IME_ACTION_GO
            setText("https://www.google.com")
        }
        bar.addView(address, LinearLayout.LayoutParams(0, dp(52), 1f))

        bar.addView(Button(this).apply {
            text = "Перейти"
            setOnClickListener { navigate() }
        })

        bar.addView(Button(this).apply {
            text = "Прокси"
            setOnClickListener { showProxyDialog() }
        })

        root.addView(bar)

        status = TextView(this).apply {
            text = "Прокси не настроен"
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        root.addView(status)

        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            webViewClient = object : WebViewClient() {
                override fun onPageFinished(view: WebView?, url: String?) {
                    super.onPageFinished(view, url)
                    if (url != null) address.setText(url)
                }
            }
            webChromeClient = WebChromeClient()
        }

        root.addView(
            web,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )

        setContentView(root)

        address.setOnEditorActionListener { _, action, _ ->
            if (action == EditorInfo.IME_ACTION_GO) {
                navigate()
                true
            } else {
                false
            }
        }

        web.loadUrl("https://www.google.com")
    }

    private fun navigate() {
        var value = address.text.toString().trim()
        if (value.isEmpty()) return

        if (!value.contains("://")) {
            value = if (value.contains(" ") || !value.contains(".")) {
                "https://www.google.com/search?q=" + URLEncoder.encode(value, "UTF-8")
            } else {
                "https://$value"
            }
        }
        web.loadUrl(value)
    }

    private fun showProxyDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(8), dp(20), 0)
        }

        val host = EditText(this).apply {
            hint = "Хост прокси (например proxy.example.com)"
            setText(proxyHost)
        }

        val port = EditText(this).apply {
            hint = "Порт"
            inputType = 2
            setText(proxyPort)
        }

        box.addView(host)
        box.addView(port)

        AlertDialog.Builder(this)
            .setTitle("Настройка HTTP-прокси")
            .setView(box)
            .setPositiveButton("Применить") { _, _ ->
                proxyHost = host.text.toString().trim()
                proxyPort = port.text.toString().trim()
                applyProxy()
            }
            .setNegativeButton("Отключить") { _, _ ->
                proxyHost = ""
                proxyPort = ""
                clearProxy()
            }
            .setNeutralButton("Отмена", null)
            .show()
    }

    private fun applyProxy() {
        val portNumber = proxyPort.toIntOrNull()
        if (proxyHost.isBlank() || portNumber == null || portNumber !in 1..65535) {
            status.text = "Укажи корректные хост и порт"
            return
        }

        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            status.text = "Текущая версия Android System WebView не поддерживает прокси"
            return
        }

        val config = ProxyConfig.Builder()
            .addProxyRule("$proxyHost:$proxyPort")
            .build()

        ProxyController.getInstance().setProxyOverride(
            config,
            Executor { command -> command.run() },
            Runnable {
                runOnUiThread {
                    status.text = "Прокси для WebView: $proxyHost:$proxyPort"
                    web.reload()
                }
            }
        )
    }

    private fun clearProxy() {
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            status.text = "Управление прокси не поддерживается этой версией WebView"
            return
        }

        ProxyController.getInstance().clearProxyOverride(
            Executor { command -> command.run() },
            Runnable {
                runOnUiThread {
                    status.text = "Прокси отключён"
                    web.reload()
                }
            }
        )
    }

    private fun dp(value: Int): Int =
        (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated by Android")
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) {
            web.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
